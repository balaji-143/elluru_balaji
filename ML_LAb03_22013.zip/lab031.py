# Q.2
import numpy as np 
A = np.array([[1, 2], [3, 4], [5, 6]])
# Assuming b is the output vector
b = np.array([1, 2, 3])
# Calculate the pseudo-inverse of A
A_pseudo_inv = np.linalg.pinv(A)
# Calculate the model vector X
X = A_pseudo_inv.dot(b)
print(X)