def findrange(numbers):
  if len(numbers) < 3:
    return "Range determination not possible"
  else:
    return max(numbers) - min(numbers)


numbers = [5, 3, 8, 1, 0, 4]
print(findrange(numbers))
