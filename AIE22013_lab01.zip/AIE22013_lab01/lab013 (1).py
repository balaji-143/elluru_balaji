def matrix_power(matrix, power):
  if not isinstance(matrix, list) or not all(
      isinstance(row, list) for row in matrix):
    raise ValueError("Input matrix should be a list of lists.")
  n = len(matrix)
  if not all(len(row) == n for row in matrix):
    raise ValueError("Input matrix should be a square matrix.")
  result = matrix.copy()
  for _ in range(power - 1):
    result = matrix_multiply(result, matrix)
  return result


def matrix_multiply(matrix1, matrix2):
  rows1, cols1 = len(matrix1), len(matrix1[0])
  rows2, cols2 = len(matrix2), len(matrix2[0])
  if cols1 != rows2:
    raise ValueError(
        "Number of columns in the first matrix should be equal to the number of rows in the second matrix."
    )
  result = [[0] * cols2 for _ in range(rows1)]
  for i in range(rows1):
    for j in range(cols2):
      for k in range(cols1):
        result[i][j] += matrix1[i][k] * matrix2[k][j]
  return result


matrix_A = [[1, 2], [3, 4]]
power_m = 3
result_matrix = matrix_power(matrix_A, power_m)
for row in result_matrix:
  print(row)
