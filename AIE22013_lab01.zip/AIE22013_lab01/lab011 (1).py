def getPairsCount(arr, n, sum):
  count = 0
  m = {}
  for i in range(n):
    if sum - arr[i] in m:
      count += m[sum - arr[i]]
    if arr[i] in m:
      m[arr[i]] += 1
    else:
      m[arr[i]] = 1
  return count


arr = [2, 7, 4, 1, 3, 6]
n = len(arr)
sum = 10
print("Count of pairs is", getPairsCount(arr, n, sum))
