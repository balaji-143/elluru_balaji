import math

def calculate_euclidean_distance(point1, point2):
  """
    Calculate Euclidean distance between two points in n-dimensional space.
          point1 (list): List of coordinates for the first point.
          point2 (list): List of coordinates for the second point.
   """
  if len(point1) != len(point2):
    raise ValueError("Points must have the same dimension")

  # Calculate the squared difference for each coordinate, sum them up, and take the square root
  squared_diff_sum = sum((x - y)**2 for x, y in zip(point1, point2))
  return math.sqrt(squared_diff_sum)

def calculate_manhattan_distance(point1, point2):
  # Calculate Manhattan distance between two points in n-dimensional space.
  if len(point1) != len(point2):
    raise ValueError("Points must have the same dimension")
  # Calculate the absolute difference for each coordinate and sum them up
  return sum(abs(x - y) for x, y in zip(point1, point2))


# Example usage
coordinate_a = [1, 2, 3]
coordinate_b = [4, 5, 6]
euclidean_distance_result = calculate_euclidean_distance(
    coordinate_a, coordinate_b)
manhattan_distance_result = calculate_manhattan_distance(
    coordinate_a, coordinate_b)
print(f"Euclidean Distance: {euclidean_distance_result}")
print(f"Manhattan Distance: {manhattan_distance_result}")
