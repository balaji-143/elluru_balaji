 
def encode_categorical(my_data):
    # Identify unique categories in the input data
    unique_cats = list(set(my_data))

    # Create a dictionary mapping each unique category to a numerical label
    label_map = {cat: label for label, cat in enumerate(unique_cats)}

    # Encode the input data using the label map
    encoded_vals = [label_map[cat] for cat in my_data]

    # Return the label map and the encoded data
    return label_map, encoded_vals

categorical_vals = ["red", "blue", "green", "red", "blue", "yellow"]

# Call the 'encode_categorical' function with the categorical values
my_label_map, my_encoded_data = encode_categorical(categorical_vals)

print("Label Map:", my_label_map)
print("Encoded Data:", my_encoded_data)
