import numpy as np
def my_knn(X_train, y_train, x_test, k):
  if len(X_train) != len(y_train):
    raise ValueError("Number of training samples and labels must be the same")
  if k > len(X_train) or k <= 0:
    raise ValueError("Invalid value of k")
  distances = []
  for i, x_train in enumerate(X_train):
    dist = np.linalg.norm(np.array(x_train) - np.array(x_test))
    distances.append((dist, y_train[i]))
  # Sort distances and get the k nearest neighbors
  sorted_distances = sorted(distances, key=lambda x: x[0])
  k_nearest_neighbors = sorted_distances[:k]
  # Count the occurrences of each class among the k neighbors
  class_counts = {}
  for _, label in k_nearest_neighbors:
    class_counts[label] = class_counts.get(label, 0) + 1
  # Choose the class with the highest count as the predicted class
  predicted_label = max(class_counts, key=class_counts.get)
  return predicted_label


# Example usage:
X_train_data = [[1, 2], [2, 3], [3, 4], [4, 5]]
y_train_data = ['A', 'B', 'B', 'A']
x_test_data = [2.5, 3.5]
k_value = 3
predicted_class = my_knn(X_train_data, y_train_data, x_test_data, k_value)
print(f"Predicted Class: {predicted_class}")
