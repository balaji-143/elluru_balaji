def one_hot_encode_categorical(my_data):  
  unique_cats = list(set(my_data))  # Get the unique categories in the data
  encoded_data = []  # Initialize a list to store the one-hot encoded data

  for category in my_data:  # Iterate through each category in the data
      one_hot_vector = [1 if cat == category else 0 for cat in unique_cats]  # Create a one-hot vector for the category
      encoded_data.append(one_hot_vector)  # Append the one-hot vector to the encoded data list

  return unique_cats, encoded_data  # Return the unique categories and the one-hot encoded data
 
categorical_vals = ["red", "blue", "green", "red", "blue", "yellow"]  # Categorical data
unique_categories, encoded_data = one_hot_encode_categorical(categorical_vals)  # Perform one-hot encoding
print("Unique Categories:", unique_categories)  # Print the unique categories
print("One-Hot Encoded Data:")  # Print the one-hot encoded data
for cat, encoded_vector in zip(categorical_vals, encoded_data):  # Iterate through the categorical values and their encoded vectors
  print(f"{cat}: {encoded_vector}")  # Print the categorical value and its encoded vector